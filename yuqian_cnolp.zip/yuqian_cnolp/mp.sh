#!/bin/bash
cd data
rm -rf MP
mkdir MP
unzip MP.zip
mv train.csv MP
mv test.csv MP
cd ..
CUDA_VISIBLE_DEVICES=1 python ./model/run.py --dataset MP --dim 8 --topic 400 --at attn