#!/bin/bash

CUDA_VISIBLE_DEVICES=1 python ./model/run.py --dataset TC --dim 16 --topic 400 --at attn --test True