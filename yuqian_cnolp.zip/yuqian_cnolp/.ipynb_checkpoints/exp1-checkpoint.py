import numpy as np

def calculate_mean_std_form(num1, num2, num3):
    numbers = np.array([num1, num2, num3])
    
    mean_val = np.mean(numbers)
    std_val = np.std(numbers)
    
    return f"{mean_val:.2f} ± {std_val:.2f}"

# 示例使用
print(calculate_mean_std_form(40.11, 40.07, 40.10))    
print(calculate_mean_std_form(53.04, 52.98, 53.03))