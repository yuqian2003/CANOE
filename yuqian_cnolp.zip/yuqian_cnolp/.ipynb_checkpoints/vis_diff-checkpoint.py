import numpy as np, matplotlib.pyplot as plt, os
plt.figure(figsize=(6,4))
for uid in range(5):
    new  = np.load(f'./attn_cache/{uid}_attn.npy')
    base = np.load(f'./attn_cache/{uid}_none.npy')
    diff = new - base
    vmax = np.percentile(abs(diff), 95)
    ax = plt.subplot(1,5,uid+1)
    ax.imshow(diff, cmap='bwr', vmin=-vmax, vmax=vmax)
    ax.set_title(f'U{uid}')
    ax.set_xticks([0,6,12,18,23]); ax.set_yticks([0,6,12,18,23])
plt.tight_layout(); plt.savefig('user_time_diff.png', dpi=300)
