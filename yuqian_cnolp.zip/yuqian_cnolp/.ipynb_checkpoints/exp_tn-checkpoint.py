#data = {
#    "Topic Num": [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800],
#    "Acc@1": [44.00, 44.10, 44.96, 45.09, 45.23, 44.51, 45.59, 44.96, 45.28, 45.54, 45.35, 45.48, 45.11, 45.46, 45.24, 45.19],
#    "Acc@3": [63.01, 63.12, 64.15, 64.10, 64.22, 63.65, 64.67, 63.92, 64.32, 64.38, 64.14, 64.56, 64.08, 64.48, 64.28, 64.03],
#    "Acc@5": [69.85, 69.99, 70.78, 70.81, 70.96, 70.48, 71.23, 70.46, 70.95, 70.76, 70.67, 71.19, 70.75, 71.04, 70.94, 70.49],
#    "Acc@10": [76.90, 76.96, 77.59, 77.50, 77.69, 77.48, 77.99, 77.32, 77.78, 77.39, 77.34, 77.81, 77.50, 77.78, 77.64, 77.40],
#    "MRR": [55.60, 55.68, 56.54, 56.60, 56.75, 56.13, 57.08, 56.42, 56.89, 56.86, 56.71, 56.97, 56.59, 56.94, 56.73, 56.60]
#}


import matplotlib.pyplot as plt
import numpy as np
import matplotlib.patches as mpatches
import matplotlib.lines as mlines

tc_data = {
    "Topic Num": [150, 250, 350, 450, 550, 650],
    "Acc@1": [44.96, 45.23, 45.59, 45.28, 45.35, 45.11],
    "MRR": [56.54, 56.75, 57.08, 56.89, 56.71, 56.59]
}

mp_data = {
    "Topic Num": [150, 250, 350, 450, 550, 650],
    "Acc@1": [41.09, 40.97, 40.99, 40.80, 40.88, 40.84],
    "MRR": [53.81, 53.73, 53.75, 53.57, 53.68, 53.54]
}

selected_topic_nums = [150, 250, 350, 450, 550, 650]

tc_filtered_acc1 = []
tc_filtered_mrr = []
for i, num in enumerate(tc_data["Topic Num"]):
    if num in selected_topic_nums:
        tc_filtered_acc1.append(tc_data["Acc@1"][i])
        tc_filtered_mrr.append(tc_data["MRR"][i])

mp_filtered_acc1 = mp_data["Acc@1"]
mp_filtered_mrr = mp_data["MRR"]

bar_colors = ['#F27970', '#BB9727', '#54B345', '#32B897', '#05B9E2', '#8983BF']
bar_hatches = ['//', '\\\\', 'xx', '++', '--', '..']

fig, (ax_tc, ax_mp) = plt.subplots(1, 2, figsize=(12, 5))
plt.subplots_adjust(wspace=0.4)

def plot_subplot(ax_main, ax_twin, title, topic_nums, acc1_values, mrr_values, acc1_ylim, mrr_ylim):
    x_indices = np.arange(len(topic_nums))
    bar_width = 0.8

    for i in range(len(topic_nums)):
        ax_main.bar(x_indices[i], acc1_values[i], width=bar_width,
                    color=bar_colors[i % len(bar_colors)],
                    hatch=bar_hatches[i % len(bar_hatches)],
                    edgecolor='black')

    ax_main.set_xlabel("", fontsize=13)
    ax_main.set_ylabel("Acc@1", color='black', fontsize=13)
    ax_main.tick_params(axis='y', labelcolor='black')
    ax_main.set_ylim(acc1_ylim[0], acc1_ylim[1])
    ax_main.set_yticks(np.arange(acc1_ylim[0], acc1_ylim[1] + 0.1, 0.1))

    ax_main.set_title(title, fontsize=14)

    mrr_line_color = 'black'
    mrr_line_marker = 'o'
    ax_twin.plot(x_indices, mrr_values, color=mrr_line_color, linestyle='-', marker=mrr_line_marker, linewidth=2)

    ax_twin.set_ylabel("MRR", color='black', fontsize=13)
    ax_twin.tick_params(axis='y', labelcolor='black')
    ax_twin.set_ylim(mrr_ylim[0], mrr_ylim[1])
    ax_twin.set_yticks(np.arange(mrr_ylim[0], mrr_ylim[1] + 0.1, 0.1))

    ax_main.set_xticks(x_indices)
    ax_main.set_xticklabels(topic_nums)
    ax_main.tick_params(axis='x', rotation=0)

    ax_main.grid(False)
    ax_twin.grid(False)

plot_subplot(ax_tc, ax_tc.twinx(), "Traffic Camera", selected_topic_nums, tc_filtered_acc1, tc_filtered_mrr,
             (44.8, 45.8), (56.5, 57.2))

plot_subplot(ax_mp, ax_mp.twinx(), "Mobile Phone", selected_topic_nums, mp_filtered_acc1, mp_filtered_mrr,
             (40.7, 41.2), (53.5, 54.0))

acc1_plot_legend_handle = mpatches.Patch(facecolor='white', edgecolor='black', hatch='//', label='Acc@1 (higher is better)')
mrr_plot_legend_handle = mlines.Line2D([], [], color='black', marker='o', linestyle='-', label='MRR (higher is better)')

fig.legend(handles=[acc1_plot_legend_handle, mrr_plot_legend_handle],
           loc='lower center',
           bbox_to_anchor=(0.5, 0.1),
           ncol=2,
           frameon=True,
           fontsize=10)

common_legend_handles = []
for i, num in enumerate(selected_topic_nums):
    patch = mpatches.Patch(facecolor=bar_colors[i % len(bar_colors)], edgecolor='black',
                           hatch=bar_hatches[i % len(bar_hatches)], label=f'$n_e$={num}')
    common_legend_handles.append(patch)

fig.legend(handles=common_legend_handles,
           loc='lower center',
           bbox_to_anchor=(0.5, 0.0),
           ncol=len(selected_topic_nums),
           frameon=True,
           fontsize=10)

plt.tight_layout(rect=[0, 0.2, 1, 1])

plt.savefig("tn.pdf", bbox_inches='tight')
plt.show()