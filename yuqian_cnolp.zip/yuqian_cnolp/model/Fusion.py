import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import torch
from torch import nn
import pandas as pd
import torch.nn.functional as F
from torch.nn import init
# os.environ['CUDA_VISIBLE_DEVICES'] = '1'
device = torch.device("cuda")
import torch, torch.nn as nn, torch.nn.functional as F, inspect

import torch, math


"""
class TransEncoder1(nn.Module):
    """
    #与原来名字相同，外部调用可以不变；唯一差别是内部每层
    #的 self_attn 被替换为 RotaryMHA。
    """
    def __init__(self, config):
        super().__init__()
        self.config = config
        input_dim   = config.Embedding.base_dim
        nhead       = 4

        # 1) 先按老方式建一个 EncoderLayer
        enc_layer = nn.TransformerEncoderLayer(
            d_model=input_dim,
            nhead=nhead,
            dim_feedforward=input_dim,
            dropout=0.1,
            activation='gelu',
            batch_first=True
        )
        enc_norm = nn.LayerNorm(input_dim)

        # 2) 再生成 Encoder；clone 时仍是 MultiheadAttention
        self.encoder = nn.TransformerEncoder(
            encoder_layer=enc_layer,
            num_layers=2,
            norm=enc_norm
        )

        # 3) 把所有层里的 self_attn 换成 RoPE 版本
        for layer in self.encoder.layers:
            layer.self_attn = RotaryMHA(
                embed_dim=input_dim,
                num_heads=nhead,
                dropout=0.1,
                batch_first=True
            )

        self.initialize_parameters()

    def forward(self, embedded_out, src_mask):
        # **不再加 PositionalEncoding**，直接送进 Encoder
        return self.encoder(embedded_out, mask=src_mask)

    def initialize_parameters(self):
        for p in self.parameters():
            if p.dim() > 1:
                init.xavier_uniform_(p)



class LSTMEncoder(nn.Module):
    def __init__(self, config):
        super(LSTMEncoder, self).__init__()
        input_dim = config.Embedding.base_dim

        self.encoder = nn.LSTM(input_size=input_dim,
                               hidden_size=input_dim,
                               num_layers=2,
                               dropout=0.1,
                               batch_first=True)
        self.initialize_parameters()

    def forward(self, out):
        out, _ = self.encoder(out)

        return out

    def initialize_parameters(self):
        for p in self.parameters():
            if p.dim() > 1:
                init.xavier_uniform_(p)
"""



def build_rope_cache(seq_len: int, dim: int, device=None):
    """
    返回 (cos, sin)，形状都是 (seq_len, dim//2)
    """
    theta = 1.0 / (10000 ** (torch.arange(0, dim, 2, device=device).float() / dim))
    pos   = torch.arange(seq_len, device=device).float()[:, None]      # (T,1)
    freqs = pos * theta                                               # (T, dim/2)

    cos, sin = torch.cos(freqs), torch.sin(freqs)
    return cos, sin


class RotaryMHA(nn.Module):
    """RoPE-Enhanced Multi-Head Attention, 专门给 nn.TransformerEncoder 用。"""

    def __init__(self, embed_dim, num_heads,
                 dropout=0.0, bias=True, batch_first=True, **kw):
        super().__init__()
        self.embed_dim   = embed_dim
        self.num_heads   = num_heads
        self.batch_first = batch_first
        self.dropout_p   = float(dropout)

        # ① 先创建核心 MHA
        core = nn.MultiheadAttention(embed_dim, num_heads,
                                     dropout=dropout, bias=bias,
                                     batch_first=True, **kw)
        self.core = core                         # 保存引用

        # ② 仅暴露 Encoder 必须的 6 个属性
        self._qkv_same_embed_dim = True          # 编码器会直接读
        self.in_proj_weight = core.in_proj_weight
        self.in_proj_bias   = core.in_proj_bias
        self.out_proj       = core.out_proj
        if hasattr(core, "merge_masks"):         # torch≥2.2 才有
            self.merge_masks = core.merge_masks

        # ③ RoPE 缓存
        self.register_buffer("_rope_cos", None, persistent=False)
        self.register_buffer("_rope_sin", None, persistent=False)

    # ---------------- util：复数旋转 ----------------
    @staticmethod
    def _rope(x, cos, sin):                      # x:(B,T,H,Dh)
        B, T, H, Dh = x.shape
        x = x.view(B, T, H, Dh // 2, 2)
        xr, xi = x.unbind(-1)
        cos = cos[:T].unsqueeze(0).unsqueeze(2)
        sin = sin[:T].unsqueeze(0).unsqueeze(2)
        return torch.stack((xr * cos - xi * sin,
                            xr * sin + xi * cos), -1).flatten(3)

    # ---------------- forward -----------------------
    def forward(self, query, key, value,
                key_padding_mask=None,
                need_weights=False,
                attn_mask=None,
                average_attn_weights=True,
                **_):
        # ---- to (B,T,C)
        if not self.batch_first:
            query, key, value = [x.transpose(0, 1) for x in (query, key, value)]
        B, T, _ = query.shape
        Dh = self.embed_dim // self.num_heads
        scale = 1 / math.sqrt(Dh)

        # ---- Q K V
        qkv = F.linear(query, self.in_proj_weight, self.in_proj_bias)
        q_proj, k_proj, v_proj = qkv.chunk(3, -1)

        # ---- 缓存
        if self._rope_cos is None or self._rope_cos.size(0) < T:
            self._rope_cos, self._rope_sin = build_rope_cache(T, Dh, query.device)

        def sh(x): return x.view(B, T, self.num_heads, Dh)
        q = self._rope(sh(q_proj), self._rope_cos, self._rope_sin)
        k = self._rope(sh(k_proj), self._rope_cos, self._rope_sin)
        v = sh(v_proj)
        q, k, v = [t.permute(0, 2, 1, 3) for t in (q, k, v)]  # (B,H,T,Dh)

        # ---- scores
        scores = (q @ k.transpose(-2, -1)) * scale            # (B,H,T,T)
        if attn_mask is not None:
            scores += attn_mask.unsqueeze(0)
        if key_padding_mask is not None:
            scores = scores.masked_fill(key_padding_mask[:, None, None, :], -1e9)

        probs = F.softmax(scores, -1)
        if self.training and self.dropout_p:
            probs = F.dropout(probs, p=self.dropout_p)

        out = (probs @ v).permute(0, 2, 1, 3).contiguous().view(B, T, self.embed_dim)
        out = self.out_proj(out)
        if not self.batch_first:
            out = out.transpose(0, 1)

        if need_weights:
            w = probs.mean(1) if average_attn_weights else probs
            if not self.batch_first: w = w.transpose(0, 1)
            return out, w
        return out

# ------------------------- CoPE -------------------------
class CoPE(nn.Module):
    def __init__(self, npos_max, head_dim, num_heads):
        super().__init__()
        self.npos_max, self.head_dim = npos_max, head_dim
        self.pos_emb = nn.Parameter(torch.zeros(num_heads, head_dim, npos_max))

    def forward(self, query, key):                          # query/key: [B,Q,H,D]
        attn = torch.einsum("bqhd,bkhd->bhqk", query, key)  # [B,H,Q,K]
        gates = torch.sigmoid(attn)
        pos  = gates.flip(-1).cumsum(-1).flip(-1).clamp(max=self.npos_max - 1)
        pf   = pos.floor().long()
        pc   = (pf + 1).clamp(max=self.npos_max - 1)

        B, H, Q, K = attn.shape
        h_idx = torch.arange(H, device=attn.device).view(1, H, 1, 1).expand(B, -1, Q, K)

        lf = self.pos_emb[h_idx, :, pf]          # [B,H,Q,K,D]
        lc = self.pos_emb[h_idx, :, pc]          # [B,H,Q,K,D]
        w  = (pos - pf.float()).unsqueeze(-1)    # [B,H,Q,K,1]
        pos_emb = ((1 - w) * lf + w * lc).sum(-1)          # [B,H,Q,K]

        return (attn + pos_emb) / math.sqrt(self.head_dim)

# ------------------ CoPETransformerLayer ----------------
class CoPETransformerLayer(nn.TransformerEncoderLayer):
    def __init__(self, d_model, nhead, dim_feedforward, dropout, npos_max):
        super().__init__(d_model, nhead, dim_feedforward, dropout,
                         activation='gelu', batch_first=True)
        self.cope = CoPE(npos_max, d_model // nhead, nhead)

    def _sa_block(self, x, attn_mask=None, key_padding_mask=None,
                  is_causal=False, **kwargs):
        B, Q, _ = x.shape
        H, D = self.self_attn.num_heads, self.self_attn.head_dim

        qkv = x.view(B, Q, H, D)                              # [B,Q,H,D]
        attn_scores = self.cope(qkv, qkv)                     # [B,H,Q,K]
        attn_probs  = torch.softmax(attn_scores, dim=-1)      # [B,H,Q,K]

        v = qkv                                              # same as x
        ctx = torch.einsum("bhqk,bkhd->bqhd", attn_probs, v)  # [B,Q,H,D]
        ctx = ctx.reshape(B, Q, H * D)                       # [B,Q,d_model]

        return self.dropout1(ctx)

# -------------------- CoPE_TransEncoder -----------------
class CoPE_TransEncoder(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.layers = nn.ModuleList([
            CoPETransformerLayer(
                d_model=config.Embedding.base_dim,
                nhead=4,
                dim_feedforward=config.Embedding.base_dim,
                dropout=0.1,
                npos_max=config.Dataset.sequence_length
            ) for _ in range(2)
        ])

    def forward(self, src, src_mask=None):
        for layer in self.layers:
            src = layer(src, src_mask)
        return src
