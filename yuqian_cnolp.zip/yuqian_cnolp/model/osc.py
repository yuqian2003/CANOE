import torch
from torch import nn
import pandas as pd
import torch.nn.functional as F
# os.environ['CUDA_VISIBLE_DEVICES'] = '1'
device = torch.device("cuda")
class Lee_Oscillator(nn.Module):
    def __init__(self):
        super(Lee_Oscillator, self).__init__()
        self.u = 1  # excitatory
        self.v = 1  # inhibitory
        self.uthreshold = 0
        self.vthreshold = 0
        self.a1 = torch.tensor([5]).to(device)
        self.a2 = torch.tensor([5]).to(device)
        self.b1 = torch.tensor([5]).to(device)
        self.b2 = torch.tensor([5]).to(device)
        self.k = torch.tensor([-500]).to(device)
        self.n = 50
    def Sig_pie(self, k):
        s = 13
        return (torch.exp(s * k) - torch.exp(-s * k)) / (torch.exp(s * k) + torch.exp(-s * k))
    def Calculatez(self, I):
        self.u = torch.randn(I.shape).to(device) * 0.01
        self.v = torch.randn(I.shape).to(device) * 0.01
        uv = torch.sub(self.u, self.v)
        kI = torch.mul(self.k, I)
        kI2 = torch.mul(kI, I)
        z = torch.add(torch.mul(uv, torch.exp(kI2)), F.relu(I))
        return z
    def forward(self, I):
        self.u = torch.zeros(I.shape).to(device)
        self.v = torch.zeros(I.shape).to(device)
        self.uthreshold = torch.tensor(0).to(device)
        self.vthreshold = torch.tensor(0).to(device) 
        z = self.Calculatez(I)

        for i in range(self.n):
            self.u = F.relu(torch.add(torch.add(torch.mul(self.a1, self.u), torch.mul(self.a2, self.v)),
                                      torch.sub(I, self.uthreshold)))
            self.v = F.relu(torch.sub(torch.sub(torch.mul(self.b1, self.u), torch.mul(self.b2, self.v)), self.vthreshold))
        z = self.Calculatez(I) 

        return z