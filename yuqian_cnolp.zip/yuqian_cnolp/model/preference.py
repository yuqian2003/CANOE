import torch.nn as nn
import torch.nn.functional as F
import torch
import math
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
device = torch.device("cuda")
from torch.nn.parameter import Parameter 
        
class UserNet(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(UserNet, self).__init__()
        self.topic_num = input_dim
        self.output_dim = output_dim
        # self.dyt = DyT(self.topic_num)
        self.block = nn.Sequential(
            nn.Linear(self.topic_num, self.topic_num * 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(self.topic_num * 2, self.topic_num)
        )
        self.final = nn.Sequential(
            nn.LayerNorm(self.topic_num),
            # DyT(self.topic_num),
            nn.Linear(self.topic_num, self.output_dim)
        )

    def forward(self, topic_vec):
        x = topic_vec
        topic_vec = self.block(topic_vec)
        topic_vec = x + topic_vec

        return self.final(topic_vec)

