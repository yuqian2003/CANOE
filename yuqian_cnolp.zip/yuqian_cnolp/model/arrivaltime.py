import torch
from torch import nn
import pandas as pd
import torch.nn.functional as F
from torch import nn
from osc import Lee_Oscillator
device = torch.device("cuda")

class ArrivalTime(nn.Module):
    def __init__(self, config):
        super(ArrivalTime, self).__init__()
        self.config = config
        self.base_dim = config.Embedding.base_dim
        self.num_heads = 4
        assert self.base_dim % self.num_heads == 0, "base_dim must be divisible by num_heads"
        self.head_dim = self.base_dim // self.num_heads
        self.num_users = config.Dataset.num_users
        self.timeslot_num = 24
        
        if config.Model.at_type == 'attn':
            self.user_preference = nn.Embedding(self.num_users, self.base_dim)
            self.w_q = nn.ModuleList(
                 [nn.Linear(self.base_dim * 2, self.head_dim) for _ in range(self.num_heads)])
            self.w_k = nn.ModuleList(
                [nn.Linear(self.base_dim, self.head_dim) for _ in range(self.num_heads)])
            self.w_v = nn.ModuleList(
                [nn.Linear(self.base_dim, self.head_dim) for _ in range(self.num_heads)])
            
            self.unify_heads = nn.Linear(self.base_dim, self.base_dim)
            
            
            self.key_trans = nn.Linear(in_features=5120, out_features=24, bias=True)
            self.query_trans = nn.Linear(in_features=24, out_features=5120, bias=True)
        self.Lee_Oscillator = Lee_Oscillator()
        self.time_head = nn.Linear(self.base_dim, self.timeslot_num)

    def forward(self, timeslot_embedded, 
                smoothed_timeslot_embedded, 
                user_embedded,
                batch_data,
                return_attn=False):
        attn_probs = None 
        user_x = batch_data['user']
        hour_x = batch_data['hour']
        
        batch_size, sequence_length = hour_x.shape
        total_sequences = batch_size * sequence_length
        hour_mask = batch_data['hour_mask'].view(batch_size * sequence_length, -1)
        
        if self.config.Model.at_type == 'attn':
            hour_x = hour_x.view(batch_size * sequence_length)
            head_outputs = []
            user_preference = self.user_preference(user_x).unsqueeze(1).repeat(1, sequence_length, 1)
            user_feature = user_preference.view(batch_size * sequence_length, -1)
            time_feature = timeslot_embedded[hour_x]
            
            query = torch.cat([user_feature, time_feature], dim=-1)
            key = smoothed_timeslot_embedded
            for i in range(self.num_heads):
                query_i = self.w_q[i](query)
                key_i = self.w_k[i](key)
                value_i = self.w_v[i](key)
                attn_scores_i = torch.matmul(query_i, key_i.T)
                scale = 1.0 / (key_i.size(-1) ** 0.5)
                attn_scores_i = attn_scores_i * scale
                attn_scores_i = attn_scores_i.masked_fill(hour_mask == 1, float('-inf'))
                attn_scores_i = self.Lee_Oscillator(attn_scores_i)
                #attn_scores_i = torch.softmax(attn_scores_i, dim=-1)
                """
                if return_attn:
                    # 把每个 head 的注意力平均，形状 (B*L , 24)
                    if attn_probs is None:
                        attn_probs = attn_scores_i
                    else:
                        attn_probs += attn_scores_i
                """
                weighted_values_i = torch.matmul(attn_scores_i, value_i)
                head_outputs.append(weighted_values_i)
            #if return_attn:
            #    attn_probs = (attn_probs / self.num_heads).view(batch_size, sequence_length, 24)
            head_outputs = torch.cat(head_outputs, dim=-1)
            head_outputs = head_outputs.view(batch_size, sequence_length, -1)
            at_emb = self.unify_heads(head_outputs)
            time_logits = self.time_head(head_outputs)
        
        #return at_emb, time_logits, attn_probs
        return at_emb, time_logits
        