import torch.nn as nn
import torch.nn.functional as F
import torch
import math
from osc import Lee_Oscillator
device = torch.device("cuda")
class CrossAttention(nn.Module):
    def __init__(self, query_dim, kv_dim, embed_dim, output_dim, num_heads=4):
        super(CrossAttention, self).__init__()
        self.num_heads = num_heads
        self.embed_dim = embed_dim
        self.head_dim = embed_dim // num_heads
        
        # 将 query 从 query_dim 投影到 embed_dim（这里 16->64）
        self.query_proj = nn.Linear(query_dim, embed_dim)
        # if key/value 的维度!= embed_dim，则进行投影；
        self.k_proj = nn.Linear(kv_dim, embed_dim) if kv_dim != embed_dim else nn.Identity()
        self.v_proj = nn.Linear(kv_dim, embed_dim) if kv_dim != embed_dim else nn.Identity()
        
        # self.attn = nn.MultiheadAttention(embed_dim=embed_dim, num_heads=num_heads)
        self.Lee_Oscillator = Lee_Oscillator()
        self.out_fc = nn.Linear(embed_dim, output_dim)  # self.out_fc = nn.Linear(embed_dim, embed_dim)

    def forward(self, query, key, value):
        """
        query: [B, L_q, query_dim]
        key:   [B, L_k, kv_dim]
        value: [B, L_k, kv_dim]
        """
        B, L_q, _ = query.size()
        B, L_k, _ = key.size()
        Q = self.query_proj(query)   # [B, L_q, embed_dim]
        K = self.k_proj(key)         # [B, L_k, embed_dim]
        V = self.v_proj(value)       # [B, L_k, embed_dim]

        # 将 Q, K, V 分成多个头: [B, L, embed_dim] -> [B, L, num_heads, head_dim]
        # 然后交换维度得到 [B, num_heads, L, head_dim]
        Q = Q.view(B, L_q, self.num_heads, self.head_dim).transpose(1, 2)   # [B, nh, L_q, hd]
        K = K.view(B, L_k, self.num_heads, self.head_dim).transpose(1, 2)   # [B, nh, L_k, hd]
        V = V.view(B, L_k, self.num_heads, self.head_dim).transpose(1, 2)   # [B, nh, L_k, hd]

        # scores -- [B, num_heads, L_q, L_k]
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.head_dim)

        scores_flat = scores.contiguous().view(B * self.num_heads, L_q, L_k)
        #scores_flat = self.Lee_Oscillator(scores_flat)
        # 恢复原始形状 ----    [B, num_heads, L_q, L_k]
        scores = scores_flat.view(B, self.num_heads, L_q, L_k)
        #scores = self.Lee_Oscillator(scores)
        attn_weights = torch.softmax(scores, dim=-1)
        # ------------------------------------ [B, num_heads, L_q, head_dim]
        #head_outputs = torch.matmul(attn_weights, V)
        head_outputs = torch.matmul(attn_weights, V)
        # 将各个头拼接回 ------------------------ [B, L_q, embed_dim]
        head_outputs = head_outputs.transpose(1, 2).contiguous().view(B, L_q, self.embed_dim)

        out = self.out_fc(head_outputs)
        return out

class MyFullyConnect(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(MyFullyConnect, self).__init__()

        self.block = nn.Sequential(
            nn.Linear(input_dim, input_dim*2),
            nn.ReLU(), # relu / leaky relu / prelu
            nn.Dropout(0.1),
            nn.Linear(input_dim*2, input_dim),
            nn.Dropout(0.1),
        )

        self.batch_norm = nn.BatchNorm1d(input_dim)
        self.drop = nn.Dropout(0.1)

        num_locations = output_dim
        self.linear_class1 = nn.Linear(input_dim, num_locations)

    def forward(self, out):
        x = out
        out = self.block(out)
        out = out + x
        out = self.batch_norm(out)
        out = self.drop(out)

        return self.linear_class1(out)