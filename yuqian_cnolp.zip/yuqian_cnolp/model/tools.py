import os
import time

import numpy as np
import torch
import yaml
from easydict import EasyDict
from torch.utils.data import DataLoader

from dataloader import MyDataset

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.manifold import TSNE
import seaborn as sns
from sklearn.metrics.pairwise import cosine_similarity


def get_config(path, easy):
    """
    get config yml
    :param easy: is easydict mode
    :param path: yml path
    :return: EasyDict format
    """
    f = open(path, 'r', encoding='utf-8')
    res = yaml.safe_load(f)
    if easy:
        return EasyDict(res)
    else:
        return res


def get_user_input():
    while True:
        user_input = input("Configuration yml file modification completed? (y/n):").strip().lower()
        if user_input == 'y':
            return True
        elif user_input == 'n':
            return False
        else:
            print("Invalid Options")

def custom_collate(batch, device, config):
    batch_dict = {
        'user': torch.tensor([item['user'] for item in batch]).to(device),
        'location_x': torch.stack([torch.tensor(item['location_x']) for item in batch]).to(device),
        'hour': torch.stack([torch.tensor(item['hour']) for item in batch]).to(device),
        'location_y': torch.tensor([item['location_y'] for item in batch]).to(device),
        'timeslot_y': torch.tensor([item['timeslot_y'] for item in batch]).to(device),
        'hour_mask': torch.stack([torch.tensor(item['hour_mask']) for item in batch]).to(device),
        'prob_matrix_time_individual': torch.stack([torch.tensor(item['prob_matrix_time_individual']) for item in batch]).to(device),
    }

    if config.Dataset.topic_num > 0:
        batch_dict['user_topic_loc'] = torch.stack([torch.tensor(item['user_topic_loc'], dtype=torch.float32) for item in batch]).to(device)

    return batch_dict

def update_config(path, key_list, value):
    """
    update config yml
    :param key_list: yml key list
    :param path: yml path
    :param value: corresponding value
    :return:
    """
    config = get_config(path, easy=False)

    current_level = config
    outer_key = key_list[0]
    inner_key = key_list[1]
    if outer_key not in current_level:
        print(f'Update config Error: outermost key {outer_key} not exist!')
        exit()
    if inner_key not in current_level[outer_key]:
        print(f'Update config Error: inner key {inner_key} not exist in {outer_key}!')
        exit()

    current_level[outer_key][inner_key] = value

    with open(path, 'w') as f_writer:
        yaml.dump(config, f_writer, default_flow_style=False)
        f_writer.close()


def get_mapper(dataset_path):
    location_mapper_path = os.path.join(dataset_path, 'location_mapper.npy')
    user_mapper_path = os.path.join(dataset_path, 'user_mapper.npy')

    if os.path.exists(location_mapper_path) and os.path.exists(user_mapper_path):
        return

    location_set = set()
    user_set = set()

    with open(os.path.join(dataset_path, 'train.csv'), encoding='utf8') as f:
        lines = f.readlines()
        for line in lines:
            elements = line.strip().split(',')
            uid = elements[0]
            item_seq = elements[1:]

            user_set.add(uid)

            for item in item_seq:
                loc = item.split('@')[0]
                location_set.add(loc)
        f.close()
    with open(os.path.join(dataset_path, 'test.csv'), encoding='utf8') as f:
        lines = f.readlines()
        for line in lines:
            elements = line.strip().split(',')
            uid = elements[0]
            item_seq = elements[1:]

            user_set.add(uid)

            for item in item_seq:
                loc = item.split('@')[0]
                location_set.add(loc)
        f.close()

    location2id = {location: idx for idx, location in enumerate(location_set)}
    user2id = {user: idx for idx, user in enumerate(user_set)}

    print('\n*** Please check the corresponding dataset configuration yml file. ***')
    print('unique location num:', len(location2id))
    print('unique user num:', len(user2id))

    #yml_modified = get_user_input()
    yml_modified = 'y'
    if yml_modified:
        np.save(location_mapper_path, location2id)
        np.save(user_mapper_path, user2id)
    else:
        print('Program Exit')
        exit()

def run_test1(dataset_path,
             model_path,
             model,
             device,
             epoch,
             test_only,
             tm,
             save_attn=False):          # ← 新增参数
    """
    Evaluate model & (可选) 缓存用户-时间注意力
    """
    # -------- 加载配置 / 数据 --------
    config_path = os.path.join(model_path, "settings.yml")
    config = get_config(config_path, easy=True)

    dataset = MyDataset(config=config,
                        dataset_path=dataset_path,
                        device=device,
                        load_mode='test',
                        tm=tm)
    batch_size = config.Model.batch_size
    dataloader = DataLoader(
        dataset, batch_size=batch_size, shuffle=False,
        num_workers=0, drop_last=True,
        collate_fn=lambda batch: custom_collate(batch, device, config)
    )
    print('Test batches:', len(dataloader))

    # -------- 加载 checkpoint（若只测） --------
    if test_only:
        ckpt = torch.load(os.path.join(model_path,
                                       f"model_checkpoint_epoch{epoch}.pth"),
                          map_location=device)
        model.load_state_dict(ckpt['model_state_dict'])
        model.to(device)

    model.eval()

    # -------- 评估指标累加器 --------
    top_k_values = [1, 3, 5, 10]
    top_k_correct_loc = np.zeros(len(top_k_values), dtype=np.int64)
    total_samples = 0
    mrr_sum = 0.0

    # -------- 注意力累计器（前 5 用户） --------
    if save_attn:
        os.makedirs('./attn_cache', exist_ok=True)
        attn_stats = {uid: {'sum': np.zeros(24, dtype=np.float64), 'cnt': 0}
                      for uid in range(5)}

    # --------– 内部函数 --------
    def evaluate(output, label, ks):
        return np.array([
            torch.sum((torch.topk(output, k=k, dim=1)[1]) == label.unsqueeze(1)).item()
            for k in ks
        ])

    def batch_mrr(output, true_labels):
        res = 0.0
        for i, pred in enumerate(output):
            sorted_idx = torch.argsort(pred, descending=True)
            pos = (sorted_idx == true_labels[i]).nonzero(as_tuple=True)[0]
            if pos.numel():
                res += 1.0 / (pos.item() + 1)
        return res

    # =================== 推理循环 ===================
    with torch.no_grad():
        for batch_data in dataloader:
            # -------- 前向（根据 save_attn 决定是否返回注意力） --------
            outputs = model(batch_data, return_attn=save_attn)
            if isinstance(outputs, tuple):
                # (loc_logits, time_logits, rank, attn?) or (loc_logits, time_logits, rank)
                if len(outputs) == 4:
                    location_output, _, _, attn = outputs
                else:
                    location_output, _, _ = outputs
                    attn = None
            else:  # 兼容旧版仅 loc_logits
                location_output, attn = outputs, None

            # -------- KPI 累加 --------
            loc_y = batch_data['location_y'].view(-1)
            total_samples += loc_y.size(0)
            top_k_correct_loc += evaluate(location_output, loc_y, top_k_values)
            mrr_sum += batch_mrr(location_output, loc_y)

            # -------- 注意力累加（仅前 5 用户） --------
            if save_attn and attn is not None:
                # attn 形状 (B, L, 24) → 取序列平均得到 (B, 24)
                attn_vec = attn.mean(dim=1)        # (B, 24)
                for i in range(attn_vec.size(0)):
                    uid = int(batch_data['user'][i])
                    if uid in attn_stats:
                        attn_stats[uid]['sum'] += attn_vec[i].cpu().numpy()
                        attn_stats[uid]['cnt'] += 1

    # =================== 结果输出 ===================
    top_k_acc = (top_k_correct_loc / total_samples) * 100
    mrr = (mrr_sum / total_samples) * 100

    result_str = (
        "*********************** Test ***********************\n"
        f"base_dim: {config.Embedding.base_dim}\n"
        f"AT_type: {config.Model.at_type} | topic_num: {config.Dataset.topic_num}\n"
        f"encoder: {config.Encoder.encoder_type}\n"
        f"Epoch {epoch + 1}: Total {total_samples} predictions\n"
        + "\n".join([f"Acc@{k}: {acc:.2f}" for k, acc in zip(top_k_values, top_k_acc)])
        + f"\nMRR: {mrr:.2f}"
    )
    print(result_str)

    # ---- 保存指标 ----
    np.save(
        os.path.join(
            model_path,
            f"acc_{epoch + 1}_topic{config.Dataset.topic_num}"
            f"_at{config.Model.at_type}"
            f"_dim{config.Embedding.base_dim}"
            f"_encoder{config.Encoder.encoder_type}"
            f"_seed{config.Model.seed}.npy"
        ),
        np.append(top_k_acc, mrr)
    )
    with open(os.path.join(model_path, 'results.txt'), 'a', encoding='utf8') as f:
        f.write(result_str + '\n\n')

    # =================== 保存注意力文件 ===================
    if save_attn:
        tag = config.Model.at_type      # 'attn' / 'none' / ...
        for uid, stat in attn_stats.items():
            if stat['cnt'] == 0:
                # 该用户在测试集中未出现，用零向量占位
                avg_vec = stat['sum']
            else:
                avg_vec = stat['sum'] / stat['cnt']
            np.save(f'./attn_cache/{uid}_{tag}.npy', avg_vec.astype(np.float32))

def run_test(dataset_path, model_path, model, device, epoch, test_only, tm):
    config_path = os.path.join(model_path, f"settings.yml")

    config = get_config(config_path, easy=True)
    dataset = MyDataset(config=config, dataset_path=dataset_path, device=device, load_mode='test',tm=tm)

    batch_size = config.Model.batch_size
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0, drop_last=True, collate_fn=lambda batch: custom_collate(batch, device, config))
    print('Test batches:', len(dataloader))

    if test_only:
        saved_model_path = os.path.join(model_path, f'model_checkpoint_epoch{epoch}.pth')
        model.load_state_dict(torch.load(saved_model_path, map_location=device)['model_state_dict'])
        model.to(device)

    model.eval()
    precision_loc = 0
    top_k_values = [1, 3, 5, 10]
    top_k_correct_loc = np.array([0 for _ in range(len(top_k_values))])
    total_samples = 0

    def evaluate(output, label, ks):
        topk_correct_counts = [
            torch.sum(
                (torch.topk(output, k=top_k, dim=1)[1] + 0) == label.unsqueeze(1)
            ).item()
            for top_k in ks
        ]
        return np.array(topk_correct_counts)

    def calculate_mrr(output, true_labels):
        res = 0.0
        for i, pred in enumerate(output):
            sorted_indices = torch.argsort(pred, descending=True)
            true_index = np.where(true_labels[i].cpu() == sorted_indices.cpu())[0]
            if len(true_index) > 0:
                res += 1.0 / (true_index[0] + 1)
        return res

    with torch.no_grad():
        for batch_data in dataloader:
            outputs = model(batch_data)
            location_output = outputs[0] if isinstance(outputs, tuple) else outputs
            location_y = batch_data['location_y']
            location_y = location_y.view(-1)
            total_samples += location_y.size(0)

            top_k_correct_loc += evaluate(location_output, location_y, top_k_values)
            precision_loc += calculate_mrr(location_output, location_y)

    top_k_accuracy_loc = [count / total_samples * 100 for count in list(top_k_correct_loc)]
    result_str = "*********************** Test ***********************\n"
    result_str += f"base_dim: {config.Embedding.base_dim} | dim: {config.Embedding.base_dim}\n"
    result_str += f"AT_type: {config.Model.at_type} | topic_num: {config.Dataset.topic_num}\n"
    result_str += f"encoder: {config.Encoder.encoder_type}\n"
    result_str += f"Epoch {epoch + 1}: Total {total_samples} predictions on Next Location:\n"
    for k, accuracy in zip(top_k_values, top_k_accuracy_loc):
        result_str += f"Acc@{k}: {accuracy:.2f}\n"
    result_str += f"MRR: {precision_loc * 100 / total_samples:.2f}"
    result_save = top_k_accuracy_loc
    result_save.append(precision_loc * 100 / total_samples)
    result_save = np.array(result_save)
    np.save(
        f"{model_path}/acc_{epoch + 1}_topic{config.Dataset.topic_num}"
        f"_at{config.Model.at_type}"
        f"_dim{config.Embedding.base_dim}_encoder{config.Encoder.encoder_type}"
        f"_seed{config.Model.seed}.npy",
        result_save)

    print(result_str)

    with open(os.path.join(model_path, 'results.txt'), 'a', encoding='utf8') as res_file:
        res_file.write(result_str + '\n\n')


def train_epoch(model, dataloader, optimizer, loss_fn, scheduler):
    model.train()
    total_loss_epoch = 0.0

    for batch_data in dataloader:
        location_output = model(batch_data)
        location_y = batch_data['location_y'].view(-1)
        location_loss = loss_fn(location_output, location_y)
        total_loss = location_loss.sum()

        optimizer.zero_grad()
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1)
        optimizer.step()
        scheduler.step()
        total_loss_epoch += total_loss.item()

    return total_loss_epoch / len(dataloader)


def save_checkpoint(save_dir, model, optimizer, best_val_loss, epoch):
    save_path = os.path.join(save_dir, f"model_checkpoint_epoch{epoch}.pth")
    torch.save({
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'best_val_loss': best_val_loss,
    }, save_path)


def get_time_str():
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())

def plot_heatmap(embedding, epoch, save_dir, feature):
    similarity_matrix = cosine_similarity(embedding.cpu().detach().numpy())
    plt.figure(figsize=(10, 8))
    sns.heatmap(similarity_matrix, cmap="YlGnBu", square=True, cbar=True, annot=False)
    plt.title(f'{feature} Embedding Similarity Heatmap at Epoch {epoch}')
    plt.savefig(os.path.join(save_dir, f'{feature}_embedding_heatmap_epoch_{epoch}.png'))
    plt.close()
    
def visualize_embeddings(epoch, loc_embedded, timeslot_embedded, user_embedded, save_dir1, save_dir2):
    embeddings = {
        'location': loc_embedded,
        'time': timeslot_embedded,
        'user': user_embedded
    }
    for feature, embedding in embeddings.items():
        # [batch_size, sequence_length, embedding_dim]  --  >  (batch_size * sequence_length, embedding_dim)
        embedding = embedding.view(-1, embedding.size(-1))
    
        #if embedding == 'timeslot_embedded':
        plot_heatmap(timeslot_embedded, epoch, save_dir2, feature)

        tsne = TSNE(n_components=3, random_state=42, max_iter=500, perplexity=10)
        reduced_embedding = tsne.fit_transform(embedding.cpu().detach().numpy())

        # UMAP --- >
        # umap_model = umap.UMAP(n_components=3, random_state=42)
        # reduced_embedding = umap_model.fit_transform(embedding.cpu().detach().numpy())
        fig = plt.figure(figsize=(8, 6))
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(reduced_embedding[:, 0], reduced_embedding[:, 1], reduced_embedding[:, 2])
        ax.set_title(f'{feature} Embedding at Epoch {epoch}')
        plt.savefig(os.path.join(save_dir1, f'{feature}_embedding_epoch_{epoch}.png'))
        plt.close(fig)

